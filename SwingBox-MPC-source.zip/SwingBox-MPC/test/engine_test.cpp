// DSP checks for Swing Box (src/swing/Swing.h). Built with AddressSanitizer + UBSan by `make test`.
// Click trains go in (one click on every 16th), and every click that comes out is checked against the swing formula,
// with the swing and the model changed live, every bar, during playback.
#include "swing/Swing.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <vector>

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)
#define NOTE(...) do { std::printf ("  ok:   "); std::printf (__VA_ARGS__); std::printf ("\n"); } while (0)

using namespace sw;
static const float SR = 48000.f;

// Independent copy of the expected position (not calling the engine).
// LinnDrum steps, written out again here so the test doesn't trust the engine's table
static int linnSnap (int pct) { const int st[6] { 50, 54, 58, 62, 66, 71 }; int b = 50; for (int v : st) if (std::abs (v - pct) < std::abs (b - pct)) b = v; return b; }

static long expectedOut (double beat, double spb, int swing, int model, double step)
{
    const double pair = 2.0 * step;
    const double pos = std::fmod (beat, pair);
    if (model == LINNDRUM) swing = linnSnap (swing);
    if (model == STRAIGHT || swing <= 50 || std::fabs (pos - step) > 1e-9) return std::lround (beat * spb);
    if (model == LINNDRUM) return std::lround ((beat - pos + pair * swing / 100.0) * spb);       // exact, no ticks
    const double ppqn = model == MPC4000 ? 960.0 : 96.0, start = beat - pos;
    double t = std::round ((start + pair * swing / 100.0) * ppqn) / ppqn;      // nearest tick...
    if (t > start + 0.75 * pair + 1e-12) t = std::floor ((start + pair * swing / 100.0) * ppqn) / ppqn;   // ...never past 75 %
    return std::lround (t * spb);
}

struct Bar { int swing, model; };

// Runs a click on every 16th through the engine (host beat, blocks of `block`), changing the settings every bar.
static void clickRun (double bpm, int block, bool silence, double stepB, const std::vector<Bar>& bars, const char* label)
{
    std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
    const double spb = SR * 60.0 / bpm;
    const long total = std::lround ((bars.size() * 4.0 + 1.0) * spb);
    std::vector<float> in (total, 0.f), out (total, 0.f), outR (total, 0.f);
    std::vector<long> exp;
    const int perBar = (int) std::lround (4.0 / stepB);
    for (int k = 0; k < (int) bars.size() * perBar; ++k)
    {
        const double beat = k * stepB;
        const long t = std::lround (beat * spb);
        in[t] = 1.f;
        const Bar& b = bars[(size_t) (k / perBar)];
        exp.push_back (expectedOut (beat, spb, b.swing, b.model, stepB));
    }
    for (long pos = 0; pos < total; pos += block)
    {
        const int m = (int) std::min<long> (block, total - pos);
        Settings s; s.bpm = bpm; s.stepBeats = stepB; s.silenceGap = silence;
        s.hostBeatValid = true; s.hostBeat = pos / spb;
        const Bar& b = bars[std::min (bars.size() - 1, (size_t) (s.hostBeat / 4.0))];
        s.swing = b.swing; s.model = b.model;
        e->process (&in[pos], &in[pos], &out[pos], &outR[pos], m, s);
    }
    std::vector<long> got; int stray = 0; double peak = 0;
    for (long t = 0; t < total; ++t)
    {
        peak = std::max (peak, (double) std::fabs (out[t]));
        if (std::fabs (out[t]) > 0.5f) got.push_back (t);
        else if (std::fabs (out[t]) > 1e-6f) ++stray;
    }
    long maxErr = 0; bool same = got.size() == exp.size();
    for (size_t i = 0; same && i < got.size(); ++i) maxErr = std::max (maxErr, std::labs (got[i] - exp[i]));
    CHECK (same, "%s: %zu clicks in, %zu out", label, exp.size(), got.size());
    CHECK (same && maxErr <= 1, "%s: max timing error %ld samples", label, maxErr);
    CHECK (stray == 0, "%s: %d stray samples (smeared or doubled clicks)", label, stray);
    CHECK (peak <= 1.0, "%s: peak %.3f", label, peak);
    if (same && maxErr <= 1 && stray == 0) NOTE ("%s: %zu clicks, all on time (max error %ld sample)", label, exp.size(), maxErr);
}

int main()
{
    std::printf ("Swing Box engine test\n");

    // ---- the swing math
    CHECK (swingDelayBeats (0.5, 50, MPC60) == 0.0, "50%% = straight");
    CHECK (std::fabs (swingDelayBeats (0.5, 66, MPC60) - (32.0 / 96.0 - 0.25)) < 1e-12, "66%% at 96 PPQN = tick 32");
    CHECK (std::fabs (swingDelayBeats (0.5, 75, MPC3000) - 0.125) < 1e-12, "75%% = a 32nd late");
    CHECK (swingDelayBeats (0.5, 70, STRAIGHT) == 0.0, "STRAIGHT ignores the swing value");
    NOTE ("swing math");

    // ---- LinnDrum: the dial snaps to its fixed swing settings
    {
        const int want[26] { 50,50,50, 54,54,54,54, 58,58,58,58, 62,62,62,62, 66,66,66,66, 71,71,71,71,71,71,71 };   // for 50..75
        bool ok = true;
        for (int p = 50; p <= 75; ++p) if (effectiveSwing (LINNDRUM, p) != want[p - 50]) { ok = false; std::printf ("  %d -> %d\n", p, effectiveSwing (LINNDRUM, p)); }
        CHECK (ok, "LinnDrum snaps 50..75 to 50/54/58/62/66/71");
        CHECK (std::fabs (swingDelayBeats (0.5, 66, LINNDRUM) - 0.08) < 1e-12, "LinnDrum 66%% is exact (no tick rounding)");
        CHECK (std::fabs (swingDelayBeats (0.5, 75, LINNDRUM) - 0.105) < 1e-12, "LinnDrum tops out at 71%%");
        if (ok) NOTE ("LinnDrum: 6 fixed swing settings, exact positions");
    }

    // ---- bit-exact pass-through when there's nothing to do
    {
        std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
        std::vector<float> a (48000), o (48000), o2 (48000);
        srand (3); for (auto& x : a) x = (float) (rand() / (double) RAND_MAX * 2 - 1);
        const int cases = 4; bool exact = true;
        for (int c = 0; c < cases; ++c)
        {
            e->reset();
            for (long pos = 0, blk = 37; pos < 48000; pos += blk, blk = blk * 7 % 500 + 1)
            {
                const int m = (int) std::min<long> (blk, 48000 - pos);
                Settings s; s.hostBeatValid = true; s.hostBeat = pos / 24000.0; s.swing = 62;
                switch (c) { case 0: s.swing = 50; break; case 1: s.model = STRAIGHT; break; case 2: s.active = false; break; default: s.hostBeatValid = false; }
                e->process (&a[pos], &a[pos], &o[pos], &o2[pos], m, s);
            }
            for (int i = 0; i < 48000; ++i) if (o[i] != a[i] || o2[i] != a[i]) { exact = false; break; }
        }
        CHECK (exact, "pass-through is bit-exact (50%%, STRAIGHT, bypass, transport stopped)");
        if (exact) NOTE ("bit-exact pass-through when idle, zero latency");
    }

    // ---- live swing changes every bar, at every tempo the spec asks for
    std::vector<Bar> bars;
    const int demo[] = { 50, 54, 57, 62, 67, 58, 50 };
    const int ab[] = { MPC60, MPC3000, LINNDRUM, MPC3000, MPC4000, MPC2000, LINNDRUM };
    int n = 0;
    for (int s : demo) bars.push_back ({ s, ab[n++ % 7] });
    for (int s = 50; s <= 75; ++s) bars.push_back ({ s, ab[n++ % 7] });
    for (int s = 75; s >= 50; --s) bars.push_back ({ s, ab[n++ % 7] });
    bars.push_back ({ 62, STRAIGHT }); bars.push_back ({ 62, MPC60 });         // live A/B: straight, then swung
    char lbl[96];
    for (double bpm : { 60.0, 90.0, 120.0, 140.0, 160.0 })
        for (int blk : { 64, 512 })
        {
            std::snprintf (lbl, sizeof lbl, "%3.0f BPM, block %3d, Repeat ", bpm, blk); clickRun (bpm, blk, false, 0.25, bars, lbl);
            std::snprintf (lbl, sizeof lbl, "%3.0f BPM, block %3d, Silence", bpm, blk); clickRun (bpm, blk, true, 0.25, bars, lbl);
        }
    // every grid, slow to fast, both gap modes
    for (int g = 0; g < kNumGrids; ++g)
        for (double bpm : { 60.0, 120.0, 160.0 })
            for (bool sil : { false, true })
            {
                std::snprintf (lbl, sizeof lbl, "grid %-5s %3.0f BPM, %s", kGridNames[g], bpm, sil ? "Silence" : "Repeat ");
                clickRun (bpm, 256, sil, kGridBeats[g], bars, lbl);
            }

    // fine grids never pass 75 % (a 1/128 pair is only 6 ticks at 96 PPQN)
    {
        bool ok = true;
        for (int g = 0; g < kNumGrids; ++g)
            for (int m = MPC60; m <= MPC4000; ++m)
                for (int sw = 50; sw <= 75; ++sw)
                {
                    const double pair = 2 * kGridBeats[g], d = swingDelayBeats (pair, sw, m);
                    if (d < -1e-12 || d > 0.25 * pair + 1e-12) ok = false;
                }
        CHECK (ok, "every grid, model and swing value: the late step stays between 50 %% and 75 %% of the pair");
        if (ok) NOTE ("all grids: swing stays within 50..75 %% after snapping to the model's ticks");
    }

    // ---- random knob twiddling on noise: never louder than the input, never NaN
    {
        std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
        const long N = 48000 * 20; std::vector<float> a (N), o (N), o2 (N);
        srand (7); for (auto& x : a) x = (float) (rand() / (double) RAND_MAX * 1.6 - 0.8);
        Settings s; s.hostBeatValid = true; s.bpm = 97;
        bool finite = true; float pk = 0;
        for (long pos = 0; pos < N; pos += 128)
        {
            if (rand() % 3 == 0) s.swing = 50 + rand() % 26;
            if (rand() % 20 == 0) s.model = rand() % kNumModels;
            if (rand() % 40 == 0) s.stepBeats = kGridBeats[rand() % kNumGrids];
            if (rand() % 40 == 0) s.silenceGap = ! s.silenceGap;
            if (rand() % 60 == 0) s.active = ! s.active;
            s.hostBeat = pos / (SR * 60.0 / s.bpm);
            e->process (&a[pos], &a[pos], &o[pos], &o2[pos], 128, s);
        }
        for (long i = 0; i < N; ++i) { if (! std::isfinite (o[i])) finite = false; pk = std::max (pk, std::fabs (o[i])); }
        CHECK (finite && pk <= 0.8f + 1e-6f, "random live changes: finite, peak %.3f <= input peak 0.8", pk);
        if (finite && pk <= 0.8f + 1e-6f) NOTE ("20 s of random live knob moves: no NaN, never louder than the input");
    }

    // ---- free mode: SYNC locks to the next hit, then the swing follows that grid
    {
        std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
        const double bpm = 100, spb = SR * 60.0 / bpm; const long start = 12345;
        const long N = start + (long) (8 * 4 * spb); std::vector<float> a (N, 0.f), o (N), o2 (N);
        std::vector<long> exp;
        for (int k = 0; k < 8 * 16; ++k) { const long t = start + std::lround (k * 0.25 * spb); if (t < N) { a[t] = 1.f; exp.push_back (start + expectedOut (k * 0.25, spb, 60, MPC60, 0.25)); } }
        Settings s; s.freeMode = true; s.bpm = bpm; s.swing = 60;
        e->armSync();
        for (long pos = 0; pos < N; pos += 256) { const int m = (int) std::min<long> (256, N - pos); e->process (&a[pos], &a[pos], &o[pos], &o2[pos], m, s); }
        std::vector<long> got; for (long t = 0; t < N; ++t) if (o[t] > 0.5f) got.push_back (t);
        long err = 0; bool same = got.size() == exp.size();
        for (size_t i = 0; same && i < got.size(); ++i) err = std::max (err, std::labs (got[i] - exp[i]));
        CHECK (same && err <= 1 && ! e->syncArmed(), "free mode + SYNC: %zu clicks, max error %ld", got.size(), err);
        if (same && err <= 1) NOTE ("free mode: SYNC locked to the first hit, %zu clicks on time", got.size());
    }

    // ---- grid offset: the grid moves, the swing follows it
    {
        std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
        const double bpm = 120, spb = SR * 60.0 / bpm, offMs = 7.0; const long off = std::lround (offMs * 0.001 * SR);
        const long N = (long) (4 * 4 * spb); std::vector<float> a (N, 0.f), o (N), o2 (N); std::vector<long> exp;
        for (int k = 0; k < 4 * 16 - 1; ++k) { a[std::lround (k * 0.25 * spb) + off] = 1.f; exp.push_back (expectedOut (k * 0.25, spb, 58, MPC60, 0.25) + off); }
        for (long pos = 0; pos < N; pos += 256)
        {
            Settings s; s.hostBeatValid = true; s.hostBeat = pos / spb; s.bpm = bpm; s.swing = 58; s.offsetMs = offMs;
            e->process (&a[pos], &a[pos], &o[pos], &o2[pos], (int) std::min<long> (256, N - pos), s);
        }
        std::vector<long> got; for (long t = 0; t < N; ++t) if (o[t] > 0.5f) got.push_back (t);
        long err = 0; bool same = got.size() == exp.size();
        for (size_t i = 0; same && i < got.size(); ++i) err = std::max (err, std::labs (got[i] - exp[i]));
        CHECK (same && err <= 1, "grid offset +7 ms: max error %ld", err);
        if (same && err <= 1) NOTE ("grid offset: clicks 7 ms late still swing correctly");
    }

    // ---- transport stops in the middle of a late step: the delay fades out, then it's bit-exact again
    {
        std::unique_ptr<AudioSwing> e (new AudioSwing); e->prepare (SR);
        const double spb = SR * 0.5; std::vector<float> a (48000), o (48000), o2 (48000);
        srand (11); for (auto& x : a) x = (float) (rand() / (double) RAND_MAX - 0.5);
        for (long pos = 0; pos < 48000; pos += 100)
        {
            Settings s; s.swing = 66; s.hostBeat = pos / spb; s.hostBeatValid = pos < (long) (0.3 * spb);  // stops at beat 0.3
            e->process (&a[pos], &a[pos], &o[pos], &o2[pos], 100, s);
        }
        bool exact = true; for (long i = 24000; i < 48000; ++i) if (o[i] != a[i]) exact = false;
        CHECK (exact && e->delaySamples() == 0, "after the transport stops: straight and bit-exact");
        if (exact) NOTE ("transport stop mid-swing: fades back to straight, then bit-exact");
    }

    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails == 0 ? 0 : 1;
}
