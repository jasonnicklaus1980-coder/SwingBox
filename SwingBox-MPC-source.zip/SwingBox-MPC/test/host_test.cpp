// Offline VST2 host test for Swing Box: loads the .so the way MPC OS does and drives it through the VST2 interface only
// (setParameter, programs, processReplacing, a host clock that reports tempo and beat), at many block sizes.
//   ./host_test build/native/swingbox.so
#include "vst2.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <string>
#include <vector>

static int fails = 0, checks = 0;
#define CHECK(cond, ...) do { ++checks; if (! (cond)) { ++fails; std::printf ("  FAIL: "); } else std::printf ("  ok:   "); \
                              std::printf (__VA_ARGS__); std::printf ("\n"); } while (0)
typedef AEffect* (*MainFn) (audioMasterCallback);
typedef const char* (*KeyFn) (int);
static KeyFn keyOf;
static VstTimeInfo gTime; static bool gTimeOn = true, gPlaying = true; static double gTempo = 120.0;
static int automates = 0;
static intptr_t host (AEffect*, int32_t op, int32_t, intptr_t, void*, float)
{
    if (op == audioMasterAutomate) ++automates;
    if (op == audioMasterGetTime)
    {
        if (! gTimeOn) return 0;
        gTime.tempo = gTempo; gTime.flags = kVstTempoValid | kVstPpqPosValid | (gPlaying ? kVstTransportPlaying : 0);
        return (intptr_t) &gTime;
    }
    return op == 1 ? 2400 : 0;
}
static AEffect* fx;
static const float SR = 48000.f;
static intptr_t D (int op, int idx = 0, intptr_t val = 0, void* p = nullptr, float opt = 0) { return fx->dispatcher (fx, op, idx, val, p, opt); }
static int idx (const char* k) { for (int i = 0; i < fx->numParams; ++i) if (std::strcmp (keyOf (i), k) == 0) return i; std::printf ("no param %s\n", k); std::exit (2); }
static void setN (const char* k, float n) { fx->setParameter (fx, idx (k), n); }
static float getN (const char* k) { return fx->getParameter (fx, idx (k)); }
static std::string text (const char* k) { char b[256] = {}; D (effGetParamDisplay, idx (k), 0, b); return b; }
static void setSwing (int pct) { setN ("swing", (pct - 50) / 25.f); }
static void setModel (int m) { setN ("model", m / 5.f); }

// Runs `in` through the plugin with the host clock advancing; hook(frame) runs before every block.
template <class F> static std::vector<float> run (const std::vector<float>& in, int block, F hook, bool accumulate = false)
{
    std::vector<float> out (in.size(), 0.f), a (4096), b (4096), l (4096), r (4096);
    const double spb = SR * 60.0 / gTempo;
    for (size_t pos = 0; pos < in.size(); pos += (size_t) block)
    {
        const int m = (int) std::min<size_t> ((size_t) block, in.size() - pos);
        hook ((long) pos);
        gTime.ppqPos = pos / spb; gTime.samplePos = (double) pos; gTime.sampleRate = SR;
        for (int i = 0; i < m; ++i) { a[i] = b[i] = in[pos + i]; l[i] = r[i] = 0.f; }
        float* ins[2] { a.data(), b.data() }; float* outs[2] { l.data(), r.data() };
        if (accumulate) fx->process (fx, ins, outs, m); else fx->processReplacing (fx, ins, outs, m);
        for (int i = 0; i < m; ++i) out[pos + i] = l[i];
    }
    return out;
}
static std::vector<long> clicks (const std::vector<float>& y) { std::vector<long> c; for (size_t t = 0; t < y.size(); ++t) if (y[t] > 0.5f) c.push_back ((long) t); return c; }
static long swungTime (double beat, double spb, int swing, int ppqn, double step = 0.25)    // independent expected position
{
    const double pair = 2 * step, pos = std::fmod (beat, pair), start = beat - pos;
    if (swing <= 50 || std::fabs (pos - step) > 1e-9) return std::lround (beat * spb);
    double t = std::round ((start + pair * swing / 100.0) * ppqn) / ppqn;
    if (t > start + 0.75 * pair + 1e-12) t = std::floor ((start + pair * swing / 100.0) * ppqn) / ppqn;
    return std::lround (t * spb);
}
static void setGrid (int g) { setN ("grid", g / 5.f); }

int main (int argc, char** argv)
{
    const char* path = argc > 1 ? argv[1] : "build/native/swingbox.so";
    void* lib = dlopen (path, RTLD_NOW | RTLD_LOCAL);
    if (lib == nullptr) { std::printf ("dlopen failed: %s\n", dlerror()); return 2; }
    MainFn mainFn = (MainFn) dlsym (lib, "VSTPluginMain");
    keyOf = (KeyFn) dlsym (lib, "SB_ParamKey");
    if (mainFn == nullptr || keyOf == nullptr) { std::printf ("missing exports\n"); return 2; }
    fx = mainFn (host);
    std::printf ("Swing Box host test (%s)\n", path);
    CHECK (fx != nullptr && fx->magic == kEffectMagic, "VSTPluginMain returns an effect");
    CHECK (fx->numInputs == 2 && fx->numOutputs == 2 && fx->initialDelay == 0, "stereo in/out, zero latency");
    D (effOpen); D (effSetSampleRate, 0, 0, nullptr, SR); D (effSetBlockSize, 0, 512); D (effMainsChanged, 0, 1);
    char nm[64] = {}; D (effGetEffectName, 0, 0, nm); CHECK (std::strcmp (nm, "Swing Box") == 0, "name: %s", nm);
    CHECK (D (effGetPlugCategory) == kPlugCategEffect, "an insert effect");

    // ---- parameters and displays
    setSwing (57); CHECK (text ("swing") == "57%", "swing shows %s", text ("swing").c_str());
    setSwing (75); CHECK (text ("swing") == "75%", "swing tops out at %s", text ("swing").c_str());
    setModel (3); CHECK (text ("model") == "MPC3000", "model shows %s", text ("model").c_str());
    setN ("bpm", 0.f); CHECK (text ("bpm") == "Host", "tempo 0 = %s", text ("bpm").c_str());
    setN ("offset", 0.5f + 7.0f / 60.f); CHECK (text ("offset") == "+7.0 ms", "grid offset shows %s", text ("offset").c_str());
    setN ("offset", 0.5f);

    // ---- presets
    char pn[64] = {}; D (effGetProgramNameIndexed, 4, 0, pn); CHECK (std::strcmp (pn, "MPC60 66% Triplet") == 0, "program 4: %s", pn);
    D (effSetProgram, 0, 8); CHECK (text ("model") == "MPC3000" && text ("swing") == "66%", "program 8 sets %s %s", text ("model").c_str(), text ("swing").c_str());
    D (effSetProgram, 0, 0);

    // ---- bit-exact when the transport is stopped, at 50 %, and on bypass
    std::vector<float> noise (48000 * 2); srand (5); for (auto& x : noise) x = (float) (rand() / (double) RAND_MAX - 0.5);
    for (int c = 0; c < 3; ++c)
    {
        setSwing (c == 1 ? 50 : 66); setN ("bypass", c == 2 ? 1.f : 0.f); gPlaying = c != 0;
        auto y = run (noise, 333, [] (long) {});
        CHECK (y == noise, "bit-exact pass-through: %s", c == 0 ? "transport stopped" : (c == 1 ? "swing 50%" : "bypass"));
    }
    setN ("bypass", 0.f); gPlaying = true;

    // ---- clicks on every 16th, swing and model changed live through setParameter, many block sizes
    const double spb = SR * 60.0 / gTempo;
    const int bars = 8; const long N = (long) (bars * 4 * spb);
    std::vector<float> train (N, 0.f);
    for (int k = 0; k < bars * 16; ++k) train[std::lround (k * 0.25 * spb)] = 1.f;
    const int sched[bars] { 54, 57, 62, 66, 58, 50, 75, 60 };
    for (int blk : { 1, 64, 256, 333, 1024, 4096 })
    {
        setModel (1); setGrid (2);
        auto y = run (train, blk, [&] (long pos) { setSwing (sched[std::min (bars - 1, (int) (pos / spb / 4.0))]); });
        auto got = clicks (y);
        std::vector<long> exp; for (int k = 0; k < bars * 16; ++k) exp.push_back (swungTime (k * 0.25, spb, sched[k / 16], 96));
        long err = 0; const bool same = got.size() == exp.size();
        for (size_t i = 0; same && i < got.size(); ++i) err = std::max (err, std::labs (got[i] - exp[i]));
        CHECK (same && err <= 1, "block %4d: %zu clicks, live swing every bar, max error %ld sample", blk, got.size(), err);
    }

    // ---- every grid through the plugin: 1/4 ... 1/128, live swing changes every bar
    const char* gname[6] { "1/4", "1/8", "1/16", "1/32", "1/64", "1/128" };
    const double gstep[6] { 1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125 };
    for (int g = 0; g < 6; ++g)
    {
        setGrid (g); CHECK (text ("grid") == gname[g], "grid shows %s", text ("grid").c_str());
        const int per = (int) std::lround (4.0 / gstep[g]);
        std::vector<float> tg (N, 0.f); std::vector<long> exp;
        for (int k = 0; k < bars * per; ++k) { tg[std::lround (k * gstep[g] * spb)] = 1.f; exp.push_back (swungTime (k * gstep[g], spb, sched[k / per], 960, gstep[g])); }
        setModel (4);
        auto got = clicks (run (tg, 256, [&] (long pos) { setSwing (sched[std::min (bars - 1, (int) (pos / spb / 4.0))]); }));
        long err = 0; const bool same = got.size() == exp.size();
        for (size_t i = 0; same && i < got.size(); ++i) err = std::max (err, std::labs (got[i] - exp[i]));
        CHECK (same && err <= 1, "grid %-5s MPC4000: %zu clicks, max error %ld sample", gname[g], got.size(), err);
    }
    setGrid (2);

    // ---- the A/B keys: radio buttons that always mirror the Model
    auto tick = [&] () { std::vector<float> s (512, 0.f); run (s, 512, [] (long) {}); };
    setModel (1); tick();
    setN ("k3000", 1.f); tick();
    CHECK (text ("model") == "MPC3000" && getN ("k3000") > 0.5f && getN ("k60") < 0.5f, "press MPC3000: model %s, MPC60 key off", text ("model").c_str());
    setN ("k3000", 0.f); tick();
    CHECK (getN ("k3000") > 0.5f && text ("model") == "MPC3000", "the lit key can't be switched off");
    setN ("kstraight", 1.f); tick();
    CHECK (text ("model") == "STRAIGHT" && getN ("k3000") < 0.5f, "live A/B to STRAIGHT");
    setModel (4); tick();
    CHECK (getN ("k4000") > 0.5f && getN ("kstraight") < 0.5f, "a Q-Link/box change of Model lights the MPC4000 key");

    setN ("klinn", 1.f); tick();
    CHECK (text ("model") == "LINNDRUM" && getN ("klinn") > 0.5f && getN ("k4000") < 0.5f, "live A/B to LINNDRUM");
    setSwing (57); { std::vector<float> s (48000, 0.f); run (s, 512, [] (long) {}); }
    CHECK (text ("info").find ("LINNDRUM 1/16 58% (dial 57%) +20.0 ms") != std::string::npos, "status: %s", text ("info").c_str());
    {
        std::vector<long> exp; for (int k = 0; k < bars * 16; ++k)
        { const double b = k * 0.25, pos = std::fmod (b, 0.5); exp.push_back (std::fabs (pos - 0.25) < 1e-9 ? std::lround ((b - pos + 0.5 * 0.62) * spb) : std::lround (b * spb)); }
        setSwing (61);                                   // snaps to 62
        auto got = clicks (run (train, 256, [] (long) {}));
        long err = 0; const bool same = got.size() == exp.size();
        for (size_t i = 0; same && i < got.size(); ++i) err = std::max (err, std::labs (got[i] - exp[i]));
        CHECK (same && err <= 1, "LinnDrum dial 61%% plays 62%%: %zu clicks, max error %ld", got.size(), err);
    }

    // ---- status line
    setModel (1); setSwing (57); tick(); tick();
    { std::vector<float> s (48000, 0.f); run (s, 512, [] (long) {}); }
    std::string st = text ("info");
    CHECK (st.find ("LOCKED") != std::string::npos && st.find ("57%") != std::string::npos, "status: %s", st.c_str());

    // ---- SYNC: switches to Free and arms; a hit locks it
    setN ("tap", 1.f); tick();
    CHECK (text ("sync") == "Free" && getN ("tap") < 0.5f, "SYNC tap: sync %s, key springs back", text ("sync").c_str());
    { std::vector<float> s (48000, 0.f); run (s, 512, [] (long) {}); }
    st = text ("info"); CHECK (st.find ("SYNC ARMED") != std::string::npos, "status: %s", st.c_str());
    {
        gTimeOn = false;                      // free mode doesn't need the host's beat
        std::vector<float> t2 (N, 0.f); const long start = 7777;
        for (int k = 0; k < 4 * 16; ++k) t2[start + std::lround (k * 0.25 * spb)] = 1.f;
        setSwing (60); setN ("bpm", 120.f / 240.f);
        auto got = clicks (run (t2, 256, [] (long) {}));
        long err = 0; bool same = got.size() == 64;
        for (int k = 0; same && k < 64; ++k) err = std::max (err, std::labs (got[(size_t) k] - (start + swungTime (k * 0.25, spb, 60, 96))));
        CHECK (same && err <= 1, "free mode locked to the first hit: %zu clicks, max error %ld", got.size(), err);
        gTimeOn = true; setN ("sync", 0.f); setN ("bpm", 0.f);
    }

    // ---- accumulating process() adds to the output
    {
        setSwing (50);
        std::vector<float> a (256, 0.25f), b (256, 0.25f), l (256, 1.f), r (256, 1.f);
        float* ins[2] { a.data(), b.data() }; float* outs[2] { l.data(), r.data() };
        fx->process (fx, ins, outs, 256);
        CHECK (l[100] == 1.25f, "accumulating process adds (%.2f)", l[100]);
    }

    D (effClose);
    std::printf ("\n%d checks, %d failed\n", checks, fails);
    return fails == 0 ? 0 : 1;
}
