# Swing Box (MPC)

MPC60, MPC2000, MPC3000, MPC4000 and LinnDrum-style swing for the **audio** in an MPC insert, locked to the MPC's beat and adjustable live while the sequence plays. A native **MPC OS VST2 insert effect** for Gen1 devices (MPC X, Live / Live II, One, Key 61, Force), built on the same toolchain, installer and skin pipeline as DJ Scratch.

    incoming audio > ring (zero-latency read) > per pair of Grid steps (1/4 .. 1/128): step 1 at delay 0, step 2 late
                   > crossfaded seams that finish just before each grid point > gap fill (repeat / silence) > output

- **Swing math:** Roger Linn's definition. Swing % is the first step's share of each pair (50 straight, 66 triplet, 75 max). The late step snaps to the model's resolution: 96 PPQN for the MPC60/2000/3000, 960 for the MPC4000. It's never placed past 75%, even on fine grids where a pair is only a few ticks long. LinnDrum mode snaps the dial to the machine's fixed settings (50/54/58/62/66/71%, recalled, not verified) and places the late step exactly.
- **Grids:** 1/4, 1/8, 1/16, 1/32, 1/64 and 1/128.
- **Live controls:** Swing, model and grid can all change during playback. Settings are read for every chunk of at most 256 frames, and only audio that hasn't played yet is affected.
- **Transparent when idle:** Pass-through is bit-exact at 50%, STRAIGHT, bypass or with the transport stopped, with zero latency.
- **Sync:** Host (the MPC sequencer position) or Free (an internal grid locked by SYNC to the next hit), plus a grid offset.
- **Screen:** Two pages (SWING, SETUP). The SWING page has a big SWING % read-out, a groove ruler showing where the late steps land, live A/B keys and a status line. See `docs/skin-preview-*.png`.

How to use it: **`mpc/INSTALL.md`**.

## Build and install
    ./scripts/build_mpc.sh <mpc-ip>   # builds the ARM plugin (cross-compiler or Docker), checks it, packages, installs over SSH
    make test                         # engine_test (ASan/UBSan) + host_test (the VST2 interface with a host clock)
    make abi32                        # 32-bit VST2 struct layout check (what the ARM MPC sees)
    python3 tools/make_skin.py docs   # regenerate the skin and previews (needs Pillow and `make native`)
    ./scripts/package.sh              # cross-compiles for ARM, verifies the ELF, makes dist/SwingBox-1.0.0-mpc-armv7.zip
    ./scripts/deploy.sh <mpc-ip>      # tar-over-ssh, runs install.sh

`package.sh` needs `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`) or Docker. GITHUB.md describes building on GitHub from a phone.

## Layout
    src/swing/Swing.h   the DSP (swing math, ring buffer, seams, gap fill, free-mode onset sync)
    src/swingbox.cpp    VST2 entry points, parameter table, presets, model keys, host tempo/beat, status line
    src/vst2.h          minimal VST2 ABI (no Steinberg SDK)
    tools/make_skin.py  TUI.json, Q-Links and PNGs for the MPC screen
    mpc/                installer, uninstaller, plugin-list entry, skin, INSTALL.md
    test/               engine_test.cpp, host_test.cpp, abi32_check.cpp

## Status
**Tested here, on x86:**
- **engine_test (237 checks, under AddressSanitizer and UBSan):** Click trains at 60, 90, 120, 140 and 160 BPM, and every grid from 1/4 to 1/128 at 60, 120 and 160 BPM, with swing and model changed every bar through every value from 50 to 75%. Both gap modes and two block sizes. Every click arrives within 1 sample of the formula, with no lost, doubled or smeared clicks. Also covers 8th-note swing, bit-exact pass-through, 20 s of random live changes (finite, never louder than the input), free-mode SYNC, grid offset, and a transport stop mid-swing.
- **host_test (44 checks):** Parameters, displays, presets, live swing via setParameter at block sizes 1 to 4096, every grid through the plugin, LinnDrum snapping, the A/B radio keys, the status line, SYNC, and accumulate mode.
- **Installer:** Tested in a fake MPC root alongside an existing DJ Scratch entry.

**Not tested on a device:** The ARM build, CPU load, whether the MPC reports beat position to an insert (Free mode is the fallback), and whether the MPC redraws plugin-driven read-outs.
