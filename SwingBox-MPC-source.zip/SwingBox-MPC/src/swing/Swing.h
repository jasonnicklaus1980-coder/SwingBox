// Swing Box DSP: MPC-style swing applied to AUDIO, locked to the beat.
//
// Roger Linn's definition: the even-numbered 16ths (or 8ths) are delayed, and the swing % is the first note's share of
// each pair (50 = straight, 66 = triplet, 75 = max). On audio that means: inside every pair, the first step plays
// untouched (zero latency), the second step plays late by the swing delay. The plugin only ever delays, so it adds no
// latency. The seams are crossfaded, and they're placed just BEFORE each grid point so hits on the grid are never smeared:
//
//   pair:      |  step 1 (delay 0)       |  step 2 (delay D)              |
//   read:       x(t) ................  fade>x(t-D) .....................fade>x(t)   (next pair)
//   gap:                                 [step .. step+D) = the end of step 1 again (Repeat) or muted (Silence)
//
// Plain C++17, no allocation after construction, no libstdc++ beyond headers.
#pragma once
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <cstring>

namespace sw
{
enum Model { STRAIGHT = 0, MPC60, MPC2000, MPC3000, MPC4000, LINNDRUM, kNumModels };

// Sequencer resolution of each MPC (pulses per quarter note). The LinnDrum isn't snapped to ticks (see below).
inline int ppqnFor (int model) { return model == MPC4000 ? 960 : 96; }

// LinnDrum (1982): swing is a fixed set of positions rather than a continuous value. These are the settings as
// recalled from Linn's LM-1 / LinnDrum documentation, NOT verified against a manual or a machine: check them against
// yours and edit this one line if they differ. The swing control snaps to the nearest one (ties go down).
constexpr int kLinnSteps[] { 50, 54, 58, 62, 66, 71 };
constexpr int kNumLinnSteps = (int) (sizeof (kLinnSteps) / sizeof (kLinnSteps[0]));

// The swing % a model actually plays for a requested value (50..75).
inline int effectiveSwing (int model, int pct)
{
    if (pct < 50) pct = 50;
    if (pct > 75) pct = 75;
    if (model == STRAIGHT) return 50;
    if (model != LINNDRUM) return pct;
    int best = kLinnSteps[0];
    for (int k = 1; k < kNumLinnSteps; ++k)
        if (std::abs (kLinnSteps[k] - pct) < std::abs (best - pct)) best = kLinnSteps[k];
    return best;
}

// The swing grids, as note values in beats (a quarter note = 1 beat). The vintage machines swung 8ths and 16ths only;
// 1/4, 1/32, 1/64 and 1/128 apply the same rule to coarser and finer steps.
constexpr int kNumGrids = 6;
const char* const kGridNames[kNumGrids] { "1/4", "1/8", "1/16", "1/32", "1/64", "1/128" };
const double kGridBeats[kNumGrids] { 1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125 };
constexpr int kGrid16 = 2;

// Swung position (in beats) of the second note of a pair, snapped to the model's resolution.
// Same math as the MIDI version of the engine. Rounding to the nearest tick is an assumption (not measured on hardware).
// On very fine grids a pair is only a few ticks long (1/128 at 96 PPQN = 6 ticks), so the snapped position never goes
// past 75 %: if rounding would, it rounds down instead.
inline double swungOffbeat (double pairStart, double pairLen, int swingPct, int model)
{
    if (model == STRAIGHT) return pairStart + 0.5 * pairLen;
    swingPct = effectiveSwing (model, swingPct);
    if (model == LINNDRUM) return pairStart + pairLen * (swingPct / 100.0);     // exact: its resolution isn't known
    const double target = pairStart + pairLen * (swingPct / 100.0);
    const double ppqn = (double) ppqnFor (model);
    double t = std::round (target * ppqn) / ppqn;
    if (t > pairStart + 0.75 * pairLen + 1e-12) t = std::floor (target * ppqn) / ppqn;
    return t;
}

// How late the second step plays, in beats.
inline double swingDelayBeats (double pairLen, int swingPct, int model)
{
    return swungOffbeat (0.0, pairLen, swingPct, model) - 0.5 * pairLen;
}

struct Settings
{
    int swing = 50;               // 50..75 %
    int model = MPC60;
    double stepBeats = 0.25;      // the swing grid: one step, in beats (0.25 = 1/16)
    bool silenceGap = false;      // the gap before a late step: false = the end of step 1 again, true = muted
    float xfadeMs = 2.f;          // seam crossfade
    bool active = true;           // false = bypass (fades back to straight)
    bool freeMode = false;        // true: the plugin keeps its own beat (SYNC locks it to a hit)
    bool hostBeatValid = false;   // host mode: the host's beat at the first frame of this call
    double hostBeat = 0.0;
    double bpm = 120.0;
    double offsetMs = 0.0;        // moves the grid later (+) or earlier (-)
};

class AudioSwing
{
public:
    static constexpr uint32_t kRing = 1u << 18, kMask = kRing - 1;    // 2.7 s at 96 kHz: far more than the longest delay

    void prepare (float rate) { sr = rate > 1000.f ? rate : 44100.f; reset(); }
    void reset()
    {
        std::memset (ringL, 0, sizeof ringL); std::memset (ringR, 0, sizeof ringR);
        w = 0; dCur = 0; dFrom = 0; dTo = 0; fading = false; fadePos = 0; fadeLen = 1; gain = 1.f;
        freeBeat = 0.0; armed = false; envF = envS = 0.f; holdoff = 0; beatNow = 0.0; haveBeat = false;
    }
    void armSync() { armed = true; }
    bool syncArmed() const { return armed; }
    bool hasBeat() const { return haveBeat; }
    double beat() const { return beatNow; }                 // beat position at the end of the last call
    int delaySamples() const { return dCur; }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const Settings& s)
    {
        const double bpm = s.bpm >= 20.0 && s.bpm <= 400.0 ? s.bpm : 120.0;
        const double spb = (double) sr * 60.0 / bpm;                         // samples per beat
        const double step = s.stepBeats > 0.0 ? s.stepBeats : 0.25, pair = 2.0 * step;
        const bool on = s.active && s.model != STRAIGHT && s.swing > 50;
        const double dBeats = on ? swingDelayBeats (pair, s.swing, s.model) : 0.0;
        int dSamp = (int) std::lround (dBeats * spb);
        if (dSamp < 0) dSamp = 0;
        if (dSamp > (int) kRing - 4) dSamp = (int) kRing - 4;
        int xf = (int) std::lround (s.xfadeMs * 0.001 * sr);
        const int xfMax = (int) (step * spb * 0.25);                          // the seams must fit inside a step
        if (xf > xfMax) xf = xfMax;
        if (xf < 8) xf = 8;
        const double lead = (xf + 2) / spb;                                   // seams finish 2 samples before the grid
        const double offBeats = s.offsetMs * 0.001 * (double) sr / spb;
        const float gStep = 1.f / (float) xf;
        const float relF = std::exp (-1.f / (0.005f * sr)), coS = 1.f - std::exp (-1.f / (0.05f * sr));

        for (int i = 0; i < n; ++i)
        {
            ringL[w] = inL[i]; ringR[w] = inR[i];

            const bool hit = onset (inL[i], inR[i], relF, coS);               // always tracked, so SYNC is ready
            bool have; double b;
            if (s.freeMode)
            {
                if (armed && hit) { freeBeat = 0.0; armed = false; }
                have = ! armed; b = freeBeat;                                   // armed = straight until the hit
                freeBeat += 1.0 / spb;
                if (freeBeat >= 64.0) freeBeat -= 64.0;                       // a whole number of pairs: no drift
            }
            else { have = s.hostBeatValid; b = s.hostBeat + i / spb; }
            b -= offBeats;

            int target = 0; float gTarget = 1.f;
            if (have && dSamp > 0)
            {
                const double p = b - std::floor (b / pair) * pair;
                if (p >= step - lead && p < pair - lead) target = dSamp;
                if (s.silenceGap && p >= step && p < step + dBeats - (double) xf / spb) gTarget = 0.f;
            }
            if (! fading && target != dCur) { fading = true; dFrom = dCur; dTo = target; fadePos = 0; fadeLen = xf; }

            float yl, yr;
            if (fading)
            {
                const float t = ((float) fadePos + 0.5f) / (float) fadeLen;
                const float a = 0.5f - 0.5f * std::cos (3.14159265f * t);
                const uint32_t r0 = (w - (uint32_t) dFrom) & kMask, r1 = (w - (uint32_t) dTo) & kMask;
                yl = (1.f - a) * ringL[r0] + a * ringL[r1];
                yr = (1.f - a) * ringR[r0] + a * ringR[r1];
                if (++fadePos >= fadeLen) { fading = false; dCur = dTo; }
            }
            else
            {
                const uint32_t r = (w - (uint32_t) dCur) & kMask;
                yl = ringL[r]; yr = ringR[r];
            }

            if (gain != gTarget) gain = gTarget > gain ? (gain + gStep > gTarget ? gTarget : gain + gStep)
                                                       : (gain - gStep < gTarget ? gTarget : gain - gStep);
            if (gain != 1.f) { yl *= gain; yr *= gain; }
            outL[i] = yl; outR[i] = yr;
            w = (w + 1) & kMask;
            beatNow = b + offBeats; haveBeat = have;
        }
    }

private:
    // A hit: the fast envelope jumps well above the slow one and above -40 dBFS.
    bool onset (float l, float r, float relF, float coS)
    {
        const float m = std::fabs (l) > std::fabs (r) ? std::fabs (l) : std::fabs (r);
        const float slow = envS;
        envF = m > envF ? m : envF * relF;
        envS += (m - envS) * coS;
        if (holdoff > 0) { --holdoff; return false; }
        if (envF > 0.01f && envF > 4.f * slow + 1e-4f) { holdoff = (int) (0.05f * sr); return true; }
        return false;
    }

    float sr = 44100.f;
    float ringL[kRing], ringR[kRing];
    uint32_t w = 0;
    int dCur = 0, dFrom = 0, dTo = 0, fadePos = 0, fadeLen = 1;
    bool fading = false;
    float gain = 1.f;
    double freeBeat = 0.0, beatNow = 0.0; bool haveBeat = false;
    bool armed = false; float envF = 0.f, envS = 0.f; int holdoff = 0;
};
} // namespace sw
