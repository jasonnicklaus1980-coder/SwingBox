// Swing Box - MPC60 / 2000 / 3000 / 4000-style swing for the AUDIO going through an MPC insert (a track, a pad, a
// program, a submix or the master), locked to the MPC's beat. A native MPC OS VST2 insert effect for Gen1 devices
// (32-bit ARM), built the same way as DJ Scratch: dependency-free VST2 core (src/vst2.h), one parameter table, a skin
// drawn by tools/make_skin.py, needs only libc/libm.
//
// The DSP is in src/swing/Swing.h. This file: parameters, presets, host tempo/beat, the model keys, the status line.
// Every control is live: the audio thread reads a snapshot of the parameters for every chunk of at most 256 frames.
#include "swing/Swing.h"
#include "vst2.h"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <new>

#define SB_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace sw;

enum ParamId
{
    P_SWING, P_MODEL, P_GRID,
    P_K_STRAIGHT, P_K_60, P_K_2000, P_K_3000, P_K_4000, P_K_LINN,
    P_SYNC, P_BPM, P_TAP, P_GAP, P_XFADE, P_OFFSET, P_BYPASS,
    P_INFO,
    P_COUNT
};
enum Kind { K_FLOAT, K_CHOICE, K_BOOL, K_TEXT };
enum Fmt { F_NUM, F_PCT, F_BPM, F_MS, F_OFFSET, F_ONOFF };

const char* const kModels[] { "STRAIGHT", "MPC60", "MPC2000", "MPC3000", "MPC4000", "LINNDRUM" };
static_assert (sizeof (kModels) / sizeof (kModels[0]) == kNumModels, "one name per model");
const char* const kSyncs[] { "Host", "Free" };
const char* const kGaps[] { "Repeat", "Silence" };

struct ParamDef { const char* key; const char* name; const char* unit; Kind kind; float lo, hi, step, def; const char* const* choices; int n; Fmt fmt; };
#define CH(a) a, (int) (sizeof (a) / sizeof (a[0]))
ParamDef kParams[P_COUNT];
void initParams()
{
    auto f = [] (int i, const char* key, const char* name, const char* unit, Kind k, float lo, float hi, float step, float def, Fmt fm)
    { kParams[i] = { key, name, unit, k, lo, hi, step, def, nullptr, 0, fm }; };
    auto c = [] (int i, const char* key, const char* name, const char* const* ch, int n, int def)
    { kParams[i] = { key, name, "", K_CHOICE, 0, (float) (n - 1), 1, (float) def, ch, n, F_NUM }; };
    f (P_SWING, "swing", "Swing", "%", K_FLOAT, 50, 75, 1, 50, F_PCT);              // whole percent, like the hardware
    c (P_MODEL, "model", "Model", CH (kModels), MPC60);
    c (P_GRID, "grid", "Grid", kGridNames, kNumGrids, kGrid16);
    f (P_K_STRAIGHT, "kstraight", "A/B Straight", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    f (P_K_60, "k60", "A/B MPC60", "", K_BOOL, 0, 1, 1, 1, F_ONOFF);
    f (P_K_2000, "k2000", "A/B MPC2000", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    f (P_K_3000, "k3000", "A/B MPC3000", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    f (P_K_4000, "k4000", "A/B MPC4000", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    f (P_K_LINN, "klinn", "A/B LinnDrum", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    c (P_SYNC, "sync", "Sync", CH (kSyncs), 0);
    f (P_BPM, "bpm", "Tempo", "BPM", K_FLOAT, 0, 240, 1, 0, F_BPM);               // 0 = follow the MPC
    f (P_TAP, "tap", "Sync Tap", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    c (P_GAP, "gap", "Gap Fill", CH (kGaps), 0);
    f (P_XFADE, "xfade", "Seam", "ms", K_FLOAT, 0.5f, 8.f, 0.5f, 2.f, F_MS);
    f (P_OFFSET, "offset", "Grid Offset", "ms", K_FLOAT, -30.f, 30.f, 0.5f, 0.f, F_OFFSET);
    f (P_BYPASS, "bypass", "Bypass", "", K_BOOL, 0, 1, 1, 0, F_ONOFF);
    kParams[P_INFO] = { "info", "Status", "", K_TEXT, 0, 1000, 0, 0, nullptr, 0, F_NUM };
}
const int kModelKey[kNumModels] { P_K_STRAIGHT, P_K_60, P_K_2000, P_K_3000, P_K_4000, P_K_LINN };
inline bool isReadout (int i) { return kParams[i].kind == K_TEXT; }

inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
inline int clampi (int x, int lo, int hi) { return x < lo ? lo : (x > hi ? hi : x); }
float toPlain (const ParamDef& d, float norm)
{
    norm = clampf (norm, 0.f, 1.f);
    if (d.kind == K_BOOL) return norm >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return std::floor (norm * (float) (d.n - 1) + 0.5f);
    float v = d.lo + norm * (d.hi - d.lo);
    if (d.step > 0.f) v = d.lo + std::floor ((v - d.lo) / d.step + 0.5f) * d.step;
    return clampf (v, d.lo, d.hi);
}
float toNorm (const ParamDef& d, float plain)
{
    if (d.kind == K_BOOL) return plain >= 0.5f ? 1.f : 0.f;
    if (d.kind == K_CHOICE) return d.n > 1 ? clampf (plain / (float) (d.n - 1), 0.f, 1.f) : 0.f;
    return clampf ((plain - d.lo) / (d.hi - d.lo), 0.f, 1.f);
}
void copyStr (void* dst, const char* src, size_t max = 24)
{
    if (dst == nullptr) return;
    std::strncpy ((char*) dst, src, max - 1);
    ((char*) dst)[max - 1] = 0;
}

// ---- presets (VST programs): model, swing and grid only; sync, tempo and setup stay as they are
struct Preset { const char* name; int model; int swing; int grid; };     // grid: index into kGridNames
const Preset kPresets[] {
    { "MPC60 Straight", MPC60, 50, 2 },     { "MPC60 54% Loosen", MPC60, 54, 2 }, { "MPC60 58%", MPC60, 58, 2 },
    { "MPC60 62% Heavy", MPC60, 62, 2 },    { "MPC60 66% Triplet", MPC60, 66, 2 }, { "MPC2000 57%", MPC2000, 57, 2 },
    { "MPC3000 54%", MPC3000, 54, 2 },      { "MPC3000 60%", MPC3000, 60, 2 },    { "MPC3000 66% Triplet", MPC3000, 66, 2 },
    { "MPC4000 55% Fine", MPC4000, 55, 2 }, { "MPC4000 63%", MPC4000, 63, 2 },    { "8th Swing 60%", MPC60, 60, 1 },
    { "1/4 Shuffle 58%", MPC4000, 58, 0 },  { "1/32 Hats 56%", MPC4000, 56, 3 },  { "1/64 Rolls 60%", MPC4000, 60, 4 },
    { "LinnDrum 54%", LINNDRUM, 54, 2 },    { "LinnDrum 62%", LINNDRUM, 62, 2 },  { "LinnDrum 66% Triplet", LINNDRUM, 66, 2 },
};
constexpr int kNumPresets = (int) (sizeof (kPresets) / sizeof (kPresets[0]));

struct Text
{
    char buf[2][128] {}; std::atomic<int> live { 0 };
    const char* get() const { return buf[live.load()]; }
    bool publish (const char* s)
    {
        if (std::strcmp (get(), s) == 0) return false;
        const int idle = 1 - live.load(); std::snprintf (buf[idle], sizeof buf[idle], "%s", s); live.store (idle); return true;
    }
};

struct Plugin
{
    AEffect fx {};
    audioMasterCallback master = nullptr;
    std::atomic<float> v[P_COUNT], nv[P_COUNT];
    std::atomic<int> pending[P_COUNT];
    float sent[P_COUNT];
    int program = 0;
    float sr = 44100.f;
    AudioSwing dsp;
    int lastModel = MPC60; bool keyWas[kNumModels] {};
    double bpmUsed = 120.0; int tempoSrc = 2;           // 0 manual, 1 host, 2 default
    bool hostBeat = false; double hostSeenSec = 0.0;    // how long the host has been reporting a running beat
    Text info; int infoGen = 0; int displayCountdown = 0;
    static constexpr int kChunk = 256;

    Plugin()
    {
        for (int i = 0; i < P_COUNT; ++i) { setPlain (i, kParams[i].def); sent[i] = 1e9f; pending[i].store (0); }
        for (int k = 0; k < kNumModels; ++k) keyWas[k] = k == MPC60;
        dsp.prepare (sr);
    }
    void setPlain (int i, float plain) { v[i].store (plain); nv[i].store (toNorm (kParams[i], plain)); }
    void setNorm (int i, float norm)
    {
        if (isReadout (i)) return;
        norm = clampf (norm, 0.f, 1.f);
        nv[i].store (norm); v[i].store (toPlain (kParams[i], norm));
        if (i == P_TAP && norm >= 0.5f) pending[i].fetch_add (1);
    }
    float get (int i) const { return v[i].load(); }
    void applyPreset (int i)
    {
        if (i < 0 || i >= kNumPresets) return;
        program = i;
        setPlain (P_MODEL, (float) kPresets[i].model); setPlain (P_SWING, (float) kPresets[i].swing); setPlain (P_GRID, (float) kPresets[i].grid);
        for (int k = 0; k < kNumModels; ++k) setPlain (kModelKey[k], k == kPresets[i].model ? 1.f : 0.f);
    }
    void notifyHostAll()
    {
        if (master == nullptr) return;
        for (int i = 0; i < P_COUNT; ++i) if (! isReadout (i)) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
        master (&fx, audioMasterUpdateDisplay, 0, 0, nullptr, 0.f);
    }
    // audio thread -> host: a value the plugin changed itself (keys springing back, the model keys, the status line)
    void send (int i, float plain)
    {
        setPlain (i, plain);
        if (plain == sent[i]) return;
        sent[i] = plain;
        if (master != nullptr) master (&fx, audioMasterAutomate, i, 0, nullptr, nv[i].load());
    }

    // The A/B keys work like radio buttons: the key pressed last wins, the lit key can't be switched off,
    // and the keys always show the Model (which a Q-Link or the Model box can also change).
    void modelKeys()
    {
        int m = clampi ((int) get (P_MODEL), 0, kNumModels - 1);
        if (m != lastModel)                                  // changed from the Model box / a Q-Link: no key was pressed
        { lastModel = m; for (int k = 0; k < kNumModels; ++k) keyWas[k] = get (kModelKey[k]) > 0.5f; }
        for (int k = 0; k < kNumModels; ++k)
        {
            const bool on = get (kModelKey[k]) > 0.5f;
            if (on && ! keyWas[k] && k != m) { m = k; send (P_MODEL, (float) k); lastModel = k; }
        }
        for (int k = 0; k < kNumModels; ++k)
        {
            const bool want = k == m;
            if ((get (kModelKey[k]) > 0.5f) != want) send (kModelKey[k], want ? 1.f : 0.f);
            keyWas[k] = want;
        }
    }

    // the host's tempo and beat (MPC sequencer position)
    void readHostTime (Settings& s)
    {
        double hostTempo = 0; s.hostBeatValid = false; s.hostBeat = 0;
        if (master != nullptr)
        {
            const intptr_t r = master (&fx, audioMasterGetTime, 0, kVstTempoValid | kVstPpqPosValid, nullptr, 0.f);
            const VstTimeInfo* ti = reinterpret_cast<const VstTimeInfo*> (r);
            if (ti != nullptr)
            {
                if ((ti->flags & kVstTempoValid) != 0 && ti->tempo >= 20.0 && ti->tempo <= 400.0) hostTempo = ti->tempo;
                if ((ti->flags & kVstPpqPosValid) != 0 && (ti->flags & kVstTransportPlaying) != 0 && ti->ppqPos >= 0.0 && hostTempo > 0)
                { s.hostBeatValid = true; s.hostBeat = ti->ppqPos; }
            }
        }
        const bool free = get (P_SYNC) > 0.5f;
        const double manual = get (P_BPM);
        // Host sync: the MPC's tempo always wins (its beat only makes sense at its tempo). Free: a typed tempo wins.
        if (! free && hostTempo > 0) { bpmUsed = hostTempo; tempoSrc = 1; }
        else if (manual >= 1.0) { bpmUsed = manual; tempoSrc = 0; }
        else if (hostTempo > 0) { bpmUsed = hostTempo; tempoSrc = 1; }
        else { bpmUsed = 120.0; tempoSrc = 2; }
        s.bpm = bpmUsed;
        s.freeMode = free;
    }
    Settings settings() const
    {
        Settings s;
        s.swing = clampi ((int) std::lround (get (P_SWING)), 50, 75);
        s.model = clampi ((int) get (P_MODEL), 0, kNumModels - 1);
        s.stepBeats = kGridBeats[clampi ((int) get (P_GRID), 0, kNumGrids - 1)];
        s.silenceGap = get (P_GAP) > 0.5f;
        s.xfadeMs = get (P_XFADE);
        s.offsetMs = get (P_OFFSET);
        s.active = get (P_BYPASS) < 0.5f;
        return s;
    }
    double delayMs (const Settings& s) const
    {
        if (effectiveSwing (s.model, s.swing) <= 50) return 0.0;
        return swingDelayBeats (2.0 * s.stepBeats, s.swing, s.model) * 60000.0 / bpmUsed;
    }
    void updateDisplay (const Settings& s)
    {
        char t[128], sw[64], tempo[32];
        std::snprintf (tempo, sizeof tempo, "%.0f BPM%s", bpmUsed, tempoSrc == 1 ? " MPC" : (tempoSrc == 2 ? " (default)" : ""));
        if (s.model == STRAIGHT) std::snprintf (sw, sizeof sw, "STRAIGHT (no swing)");
        else if (effectiveSwing (s.model, s.swing) <= 50) std::snprintf (sw, sizeof sw, "%s 50%% (straight)", kModels[s.model]);
        else
        {
            const int eff = effectiveSwing (s.model, s.swing);
            char dial[24] = "";
            if (eff != s.swing) std::snprintf (dial, sizeof dial, " (dial %d%%)", s.swing);     // LinnDrum: snapped to its steps
            std::snprintf (sw, sizeof sw, "%s %s %d%%%s %+.1f ms", kModels[s.model], kGridNames[clampi ((int) get (P_GRID), 0, kNumGrids - 1)], eff, dial, delayMs (s));
        }
        if (! s.active) std::snprintf (t, sizeof t, "BYPASS");
        else if (s.freeMode && dsp.syncArmed()) std::snprintf (t, sizeof t, "SYNC ARMED: next hit = the 1 | %s", tempo);
        else if (s.freeMode) std::snprintf (t, sizeof t, "FREE %s | %s", tempo, sw);
        else if (s.hostBeatValid) std::snprintf (t, sizeof t, "LOCKED %s | %s", tempo, sw);
        else if (hostSeenSec <= 0.0) std::snprintf (t, sizeof t, "WAITING FOR THE MPC BEAT: press PLAY  (none? Sync = Free + SYNC)");
        else std::snprintf (t, sizeof t, "STOPPED (straight until PLAY) | %s", sw);
        if (! info.publish (t)) return;
        infoGen = (infoGen + 1) % 1000;
        send (P_INFO, (float) infoGen);
    }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, Settings& s)
    {
        dsp.process (inL, inR, outL, outR, n, s);
        if (s.hostBeatValid) { s.hostBeat += n * bpmUsed / (60.0 * sr); hostSeenSec += n / (double) sr; }
    }
    void block (float** in, float** out, int32_t n, bool accumulate)
    {
        Settings s = settings();
        readHostTime (s);
        if (pending[P_TAP].exchange (0) > 0)                       // SYNC: arm (and switch to Free, where it belongs)
        {
            if (get (P_SYNC) < 0.5f) { send (P_SYNC, 1.f); s.freeMode = true; }
            dsp.armSync();
            send (P_TAP, 0.f);
        }
        modelKeys();
        s.model = clampi ((int) get (P_MODEL), 0, kNumModels - 1);
        float tl[kChunk], tr[kChunk];
        for (int32_t pos = 0; pos < n; pos += kChunk)
        {
            const int m = (n - pos) < kChunk ? (int) (n - pos) : kChunk;
            if (accumulate)
            {
                process (in[0] + pos, in[1] + pos, tl, tr, m, s);
                for (int i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
            }
            else process (in[0] + pos, in[1] + pos, out[0] + pos, out[1] + pos, m, s);
        }
        if ((displayCountdown -= n) <= 0) { displayCountdown = (int) (0.1f * sr); updateDisplay (s); }
    }

    void display (int i, char* out, size_t max) const
    {
        const ParamDef& d = kParams[i];
        const float p = get (i);
        if (d.kind == K_TEXT) { std::snprintf (out, max, "%s", info.get()); return; }
        if (d.kind == K_CHOICE) { std::snprintf (out, max, "%s", d.choices[clampi ((int) p, 0, d.n - 1)]); return; }
        switch (d.fmt)
        {
            case F_PCT:    std::snprintf (out, max, "%d%%", (int) std::lround (p)); return;
            case F_BPM:    if (p < 1.f) std::snprintf (out, max, "Host"); else std::snprintf (out, max, "%.0f BPM", (double) p); return;
            case F_MS:     std::snprintf (out, max, "%.1f ms", (double) p); return;
            case F_OFFSET: std::snprintf (out, max, "%+.1f ms", (double) p); return;
            case F_ONOFF:  std::snprintf (out, max, p > 0.5f ? "On" : "Off"); return;
            default:       std::snprintf (out, max, "%.2f", (double) p); return;
        }
    }
};

// ---------------------------------------------------------------------------------------------- VST2 entry points
void processReplacing (AEffect* e, float** in, float** out, int32_t n) { static_cast<Plugin*> (e->object)->block (in, out, n, false); }
void processAccumulating (AEffect* e, float** in, float** out, int32_t n) { static_cast<Plugin*> (e->object)->block (in, out, n, true); }
void setParameter (AEffect* e, int32_t i, float norm) { if (i >= 0 && i < P_COUNT) static_cast<Plugin*> (e->object)->setNorm (i, norm); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? static_cast<Plugin*> (e->object)->nv[i].load() : 0.f; }
intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = static_cast<Plugin*> (e->object);
    switch (op)
    {
        case effClose:            p->~Plugin(); std::free (p); return 0;
        case effSetProgram:       p->applyPreset ((int) val); p->notifyHostAll(); return 0;
        case effGetProgram:       return p->program;
        case effGetProgramName:   copyStr (ptr, kPresets[p->program].name); return 0;
        case effGetProgramNameIndexed: if (idx < 0 || idx >= kNumPresets) return 0; copyStr (ptr, kPresets[idx].name); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].name); return 0;
        case effGetParamLabel:    if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParams[idx].unit, 8); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr != nullptr) { char b[128]; p->display (idx, b, sizeof b); copyStr (ptr, b, 64); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && ! isReadout (idx)) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->dsp.prepare (opt); } return 0;
        case effMainsChanged:     if (val) p->dsp.prepare (p->sr); return 0;
        case effSetBypass:        p->setPlain (P_BYPASS, val ? 1.f : 0.f); return 1;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "Swing Box", 32); return 1;
        case effGetVendorString:  copyStr (ptr, "ScratchLab", 32); return 1;
        case effGetVendorVersion: return 1000;
        case effGetPlugCategory:  return kPlugCategEffect;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 1;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:            return (ptr != nullptr && std::strcmp ((const char*) ptr, "bypass") == 0) ? 1 : 0;
        default: return 0;
    }
}
void initOnce() { static bool done = false; if (! done) { initParams(); done = true; } }
} // namespace

SB_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    initOnce();
    void* mem = std::calloc (1, sizeof (Plugin));   // no operator new: keeps libstdc++ out of the link
    if (mem == nullptr) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    p->applyPreset (0);
    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = kNumPresets;
    fx.numParams = P_COUNT;
    fx.numInputs = 2;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing;
    fx.initialDelay = 0;                              // only ever delays the late steps: no latency
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('S' << 24) | ('W' << 16) | ('B' << 8) | 'X';   // 'SWBX' = 0x53574258
    fx.version = 1000;
    return &fx;
}
// stable parameter keys for tools/make_skin.py
SB_EXPORT const char* SB_ParamKey (int i) { initOnce(); return (i >= 0 && i < P_COUNT) ? kParams[i].key : ""; }
SB_EXPORT int SB_ParamCount() { return P_COUNT; }
SB_EXPORT const char* SB_PresetName (int i) { return (i >= 0 && i < kNumPresets) ? kPresets[i].name : ""; }
SB_EXPORT int SB_PresetCount() { return kNumPresets; }
