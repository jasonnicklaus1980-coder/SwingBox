#!/bin/sh
# One-step installer for the MPC. Upload SwingBox-1.0.0-mpc-armv7.zip (the BUILT zip, not the source zip)
# to /tmp with any SFTP tool, then on the MPC as root:
#   sh /tmp/setup.sh            (download setup.sh next to the zip), or just:
#   cd /tmp && sh -c "$(cat setup.sh)"
# It finds the zip, unpacks it with whatever the device has (unzip, busybox unzip, or python3), and runs install.sh.
set -e
cd /tmp
ZIP=$(ls -t /tmp/SwingBox-*-mpc-armv7.zip 2>/dev/null | head -n 1)
if [ -z "$ZIP" ]; then
    if ls /tmp/SwingBox-MPC-source.zip >/dev/null 2>&1; then
        echo "error: /tmp has the SOURCE zip. It contains no compiled plugin." >&2
        echo "Build it on GitHub (see GITHUB.md) and upload SwingBox-1.0.0-mpc-armv7.zip instead." >&2
    else
        echo "error: no SwingBox-*-mpc-armv7.zip in /tmp. Upload it there first." >&2
    fi
    exit 1
fi
echo "Unpacking $ZIP"
rm -rf /tmp/SwingBox-1.0.0
if command -v unzip >/dev/null 2>&1; then unzip -o -q "$ZIP" -d /tmp
elif command -v busybox >/dev/null 2>&1 && busybox unzip -h >/dev/null 2>&1; then busybox unzip -o -q "$ZIP" -d /tmp
elif command -v python3 >/dev/null 2>&1; then python3 -c 'import sys, zipfile; zipfile.ZipFile(sys.argv[1]).extractall("/tmp")' "$ZIP"
else echo "error: no unzip, busybox unzip or python3 on this device. Unzip on your computer and upload the SwingBox-1.0.0 folder instead (INSTALL.md)." >&2; exit 1; fi
[ -f /tmp/SwingBox-1.0.0/install.sh ] || { echo "error: install.sh not found after unpacking" >&2; exit 1; }
# zips made on some systems lose the exec bit; install.sh is run through sh anyway
exec sh /tmp/SwingBox-1.0.0/install.sh "$@"
