# Swing Box 1.0

MPC60, MPC2000, MPC3000, MPC4000 and LinnDrum-style swing for the **audio** going through an MPC insert. Put it on a drum track, a pad, a program, a submix or the master, and it swings the sound in time with the MPC's sequencer. You can turn the swing while the sequence plays. A native MPC OS VST2 **insert effect** with a two-page touchscreen skin.

## Requirements
- **Device:** A first-generation MPC OS standalone device (32-bit ARM: MPC X, Live / Live II, One, Key 61, Force).
- **Root shell access (SSH):** Installing plugins this way is unofficial, so back up first and use it at your own risk.

## Install
Use the same steps as DJ Scratch. From your computer, run `./scripts/build_mpc.sh <mpc-ip>` in the project folder. Or upload `SwingBox-1.0.0-mpc-armv7.zip` and `setup.sh` to `/tmp` with Terminus and run `sh /tmp/setup.sh`.

The installer copies `swingbox.so` to `/sdcard/vst/` and the skin to `/sdcard/Synths/ScratchLab - VST - Swing Box/`. It backs up `MPC.settings`, adds the plugin to the plugin list, and restarts MPC (save your project first). Other plugins already installed, such as DJ Scratch, stay where they are. Re-running the installer upgrades in place.

**MPC One / Live:** If the plugin doesn't load from the SD card, install it on the internal drive with `sh install.sh -t /media/az01-internal/vst`.

## Quick start
1. Add **Swing Box** as an insert on a drum track, or on the submix or program your drums play through.
2. Press **PLAY**. The status line should say **LOCKED 92 BPM MPC**.
3. Turn **Q-Link 1** (or drag the big SWING read-out). You hear the groove change on the next beat, without stopping.
4. Tap **STRAIGHT / MPC60 / MPC2000 / MPC3000 / MPC4000 / LINNDRUM** to compare while it plays.

## How it works
Inside every pair of steps of the **Grid** (1/4, 1/8, **1/16** by default, 1/32, 1/64 or 1/128), the first step plays untouched and the second plays late. The swing % is Roger Linn's definition, the first step's share of the pair: **50% = straight, 54% loosens a straight beat, 62% is heavy, 66% is a perfect triplet, 75% is the maximum**.

**How the models differ:** The MPC60, 2000 and 3000 place the late step on a 96-steps-per-beat grid, so the swing moves in small jumps and neighbouring percentages can land on the same position. The MPC4000 uses a 960-step grid, so every percentage is distinct. How the original firmware rounded is an assumption, not measured on hardware. The MPC60 and MPC3000 modes sound identical, because the math and the resolution are the same.

**LinnDrum:** Roger Linn's 1982 drum machine had a fixed set of swing settings rather than a continuous control. In LINNDRUM mode, the swing control snaps to the nearest one: **50, 54, 58, 62, 66 or 71%**. For example, dialling 57% plays 58%, and the status line shows "58% (dial 57%)". The late step is placed exactly, without snapping to ticks, because the LinnDrum's internal timing resolution isn't known here. These six values are recalled from Linn's LM-1 / LinnDrum documentation and **haven't been checked against a manual or a machine**. If yours differ, they're one line in `src/swing/Swing.h` (`kLinnSteps`). The LinnDrum only swung 8ths and 16ths too; the other grids apply the same steps.

**Grids:** The vintage machines only swung 8ths and 16ths. The 1/4, 1/32, 1/64 and 1/128 grids apply the same rule to coarser and finer steps:
- **1/4:** A lazy, half-time shuffle on the beats themselves.
- **1/32 and 1/64:** Swing for fast hi-hats, rolls and ratchets.
- **1/128:** Closer to a flam or stutter texture than a groove, because the steps are only a few milliseconds long.

**Fine grids need the MPC4000 model.** On the 96 PPQN models, a fine-grid pair is only a few ticks long, so the swing jumps in coarse steps. At 1/32 there are 7 positions, at 1/64 there are 4, and at 1/128 there are only 2: 50 to 58% stay straight, and 59 to 75% all land at about 67%. The late step is never placed past 75%. The MPC4000 model (960 PPQN) keeps every percentage distinct down to 1/64, and has 16 distinct positions at 1/128.

**Timing:** The plugin adds **no latency**. It never plays anything early; it only delays the late steps. When the swing is at 50%, the model is STRAIGHT, the plugin is bypassed or the sequencer is stopped, the sound passes through bit-exact.

**The gap:** Delaying the second step leaves a short gap before it. **Gap Fill** decides what plays there:
- **Repeat** (default) plays the end of the first step again. This is good for loops and anything with a tail.
- **Silence** mutes the gap. This gives cleaner, tighter hits on dry drums.

**Seam** is the tiny crossfade at each joint (1 to 3 ms is right for most material). The seams finish just before each grid point, so hits on the grid keep their attack.

**Best results:** Swing Box works best on drums and percussion that sit on the 16th grid. Notes between grid points can be repeated in Repeat mode at extreme settings. Long sustained sounds (pads, 808 tails) can smear slightly at the seams. In those cases, swing just the drum track or submix.

## Sync
- **Host** (default): The plugin follows the MPC sequencer's position and tempo. It swings only while the sequence plays, and is straight when stopped.
- **Free:** Use this if the status line keeps saying **WAITING FOR THE MPC BEAT** while the sequence plays, which means the MPC isn't reporting its position to inserts. Tap **SYNC** (it switches to Free and arms). The next hit is taken as the 1, and the plugin keeps its own grid at the **Tempo** you set (or the MPC's tempo, if it reports one). Re-tap SYNC any time the grid drifts.
- **Grid Offset** (-30 to +30 ms): Nudges the grid if the swing feels early or late, for example if the audio reaching the insert is a few milliseconds behind the sequencer.

## Q-Links
| Page | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SWING | Swing | Model | Grid | Grid offset | Sync | Tempo | Gap fill | Seam | SYNC | Bypass | Straight key | MPC60 key |
| SETUP | Swing | Model | Grid | Grid offset | Sync | Tempo | Gap fill | Seam | SYNC | Bypass | MPC4000 key | LinnDrum key |

The swing value steps in whole percent from 50 to 75, like the hardware. There's no "centre = straight" position, because MPC swing has no values below 50%.

## Presets
MPC60 Straight, MPC60 54% Loosen, MPC60 58%, MPC60 62% Heavy, MPC60 66% Triplet, MPC2000 57%, MPC3000 54%, MPC3000 60%, MPC3000 66% Triplet, MPC4000 55% Fine, MPC4000 63%, 8th Swing 60%, 1/4 Shuffle 58%, 1/32 Hats 56%, 1/64 Rolls 60%, LinnDrum 54%, LinnDrum 62%, LinnDrum 66% Triplet. Presets set only the model, swing and grid.

## Not tested on a device yet
- **What has been tested:** The DSP and the VST2 interface were tested on x86. That covers clicks on every step of every grid (1/4 to 1/128) at 60 to 160 BPM, with the swing and model changed every bar during playback (every value from 50 to 75%), block sizes from 1 to 4096 frames, bit-exact pass-through, free-mode SYNC, grid offset, and 20 s of random live knob moves with no NaNs and no overshoot.
- **What still needs a device:** The ARM build (no ARM compiler where this was written), CPU load, whether the MPC reports its beat position to inserts (if not, use Free), and whether the MPC redraws the status line and the A/B keys when the plugin changes them. The skin follows the same rules as the DJ Scratch and SP1200 skins.

## Uninstall
`sh uninstall.sh` (add `-t DIR` if you installed with `-t`).
