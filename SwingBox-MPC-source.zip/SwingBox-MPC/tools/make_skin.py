#!/usr/bin/env python3
"""Generate the Swing Box MPC screen skin (same skin pipeline and MPC rules as the DJ Scratch / SP1200 skins).

An original warm-grey sampler-style panel with a green LCD. Two pages (MPC screen tabs):
  SWING  the big SWING % read-out (drag it or turn Q-Link 1), a groove ruler that shows where the late steps land,
         live A/B keys (STRAIGHT / MPC60 / MPC2000 / MPC3000 / MPC4000), grid, sync, tempo, SYNC, BYPASS, status
  SETUP  gap fill, seam crossfade, grid offset, sync and tempo, model, with a printed guide
Every control is bound to "Parameter N"; the indices come from the built plugin (SB_ParamKey), so run `make native` first.
MPC rules (proven on an MPC X with the SP1200 skin): square filmstrip frames, 128 frames, numFrames = last frame index (127),
pieces at most 84 px wide, the knob fully inside its parent box.  Requires Pillow.
Usage: python3 tools/make_skin.py [preview-dir]          (SB_LIB=path/to/swingbox.so to use another build)
"""
import ctypes, json, os, random, shutil, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIN_NAME = "ScratchLab - VST - Swing Box"          # MPC looks for "<manufacturer> - VST - <plugin name>"
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", SKIN_NAME)
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
W, H = 1280, 628
FRAMES, NUMFRAMES, SS = 128, 127, 4

FONT_DIRS = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
def font(size, name="DejaVuSans-Bold.ttf"):
    for d in FONT_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()

# ---------- palette: warm grey panel, charcoal print, green LCD, red LEDs ----------
BODY    = (190, 186, 176)
BODY_DK = (160, 156, 146)
INK     = (34, 34, 36)
INK_DIM = (88, 86, 82)
RULE    = (120, 116, 108)
LED     = (232, 52, 36)
LCD_BG  = (22, 30, 20)
LCD_TXT = (150, 230, 120)
KEYFACE, KEYFACE_DN = (226, 222, 212), (200, 196, 186)
FOCUS_COL, LCD_COL = "ffe83424", "ff96e678"

def rgba(c, a=255): return (c[0], c[1], c[2], a)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def text_c(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)
def spaced(s, n=1): return (" " * n).join(s)

# ---------- keys: a pale rubber key with a red LED ----------
KEY_W, KEY_H = 64, 66
BIG_W = 112
def key_image(on, w=KEY_W, h=KEY_H):
    s = SS
    im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = w * s / 2; kw, kt, kb = (w / 2 - 10) * s, 18 * s, 50 * s
    if on:
        g = Image.new("RGBA", im.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).ellipse([cx - 9 * s, 2 * s, cx + 9 * s, 16 * s], fill=(255, 60, 30, 170))
        im.alpha_composite(g.filter(ImageFilter.GaussianBlur(3 * s))); d = ImageDraw.Draw(im)
    d.ellipse([cx - 4 * s, 5 * s, cx + 4 * s, 13 * s], fill=rgba(LED if on else (96, 40, 34)), outline=rgba((60, 58, 56)), width=s)
    d.rounded_rectangle([cx - kw + 2 * s, kt + 3 * s, cx + kw + 2 * s, kb + 3 * s], radius=4 * s, fill=(0, 0, 0, 90))
    off = 2 * s if on else 0
    face = KEYFACE_DN if on else KEYFACE
    d.rounded_rectangle([cx - kw - 2 * s, kt + off - 2 * s, cx + kw + 2 * s, kb + off + 2 * s], radius=5 * s, fill=rgba((96, 94, 90)))
    d.rounded_rectangle([cx - kw, kt + off, cx + kw, kb + off], radius=4 * s, fill=rgba(face))
    d.line([cx - kw + 3 * s, kt + off + s, cx + kw - 3 * s, kt + off + s], fill=rgba((250, 248, 242)), width=s)
    return im.resize((w, h), Image.LANCZOS)

# ---------- the groove ruler: where the late steps land, for every swing value (4 square 84 px pieces side by side) ----------
RP, RN = 84, 4
def ruler_swing(frame): return round(50 + 25 * frame / NUMFRAMES)
def ruler_strips():
    strips = [Image.new("RGBA", (RP, RP * FRAMES), (0, 0, 0, 0)) for _ in range(RN)]
    wtot = RP * RN
    for f in range(FRAMES):
        sw = ruler_swing(f)
        fr = Image.new("RGBA", (wtot * SS, RP * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(fr)
        x0, x1 = 14 * SS, (wtot - 14) * SS
        X = lambda beat: x0 + (x1 - x0) * beat / 1.0                          # two pairs of steps, whatever the Grid
        d.line([x0, 56 * SS, x1, 56 * SS], fill=rgba(mix(LCD_TXT, LCD_BG, 0.6)), width=SS)
        for k in range(5):                                                     # the straight steps
            d.line([X(k / 4), 50 * SS, X(k / 4), 62 * SS], fill=rgba(mix(LCD_TXT, LCD_BG, 0.55)), width=SS)
        for p in (0.0, 0.5):
            for beat, late in ((p, False), (p + 0.5 * sw / 100.0, sw > 50)):
                xx = X(beat); col = LCD_TXT
                d.rounded_rectangle([xx - 5 * SS, 18 * SS, xx + 5 * SS, 46 * SS], radius=2 * SS, fill=rgba(col))
                if late:
                    d.line([X(p + 0.25), 32 * SS, xx - 7 * SS, 32 * SS], fill=rgba(mix(LCD_TXT, LCD_BG, 0.35)), width=2 * SS)
        fr = fr.resize((wtot, RP), Image.LANCZOS)
        for k in range(RN): strips[k].paste(fr.crop((k * RP, 0, (k + 1) * RP, RP)), (0, f * RP))
    return strips

# ---------- TUI.json (same schema as the SP1200 / GlueBus / DJ Scratch skins) ----------
NOREMAP = {"version": 1, "map": []}
def bounds(b, focus="No", show="Show", visible="Always"):
    return {"version": 2, "acceptsHWFocus": focus, "showWhenDataModelInvalid": show, "whenVisible": visible,
            "boundsType": "Absolute", "bounds": " ".join(str(int(v)) for v in b), "additionalInvalidatingHandles": []}
def comp(name, typ, data, b, remap=None):
    return {"version": 2, "componentData": {"version": 1, "name": name, "type": typ, "data": data},
            "handle remapping": remap or NOREMAP, "bounds": b}
def action(on, handler, extra=""):
    return {"version": 2, "onAction": on, "handler": handler, "handleName": "" if handler == "Show Overlay" else "Data",
            "additionalData": extra, "handle remapping": NOREMAP}
def bgdata(col="0"): return {"version": 1, "focussed": {"version": 1, "colour": col, "image": ""}, "unfocussed": {"version": 1, "colour": col, "image": ""}}
def definition(actions, parts, bgcol="0", ignore=False):
    return {"version": 4, "actions": actions, "backgroundData": bgdata(bgcol), "ignoreMousePresses": ignore,
            "disableCoarseDataWheel": False, "repeats": 1, "hideQLinkBounds": True, "componentsData": parts}
def label(kind, h, colour, b, case="Original", name=None):
    return comp(name or kind, "Label", {"version": 1, "textStyle": {"version": 1, "font": {"version": 1, "name": "Titillium Web", "style": "SemiBold", "height": float(h)},
                "colour": colour, "justification": "horizontallyCentred verticallyCentred", "case": case}, "type": kind, "handleName": "Data"}, bounds(b))
def focus(b):
    return comp("Focus", "Focus", {"version": 1, "backgroundColour": "00000000", "outlineColour": FOCUS_COL, "backgroundInset": 2.0, "outlineThickness": 2.0},
                bounds(b, visible="WhenFocussed"))

# ---------- parameter indices from the built plugin ----------
LIB = os.environ.get("SB_LIB", os.path.join(ROOT, "build", "native", "swingbox.so"))
def load_keys():
    lib = ctypes.CDLL(LIB)
    lib.SB_ParamKey.restype = ctypes.c_char_p; lib.SB_ParamKey.argtypes = [ctypes.c_int]
    lib.SB_ParamCount.restype = ctypes.c_int
    return {lib.SB_ParamKey(i).decode(): i for i in range(lib.SB_ParamCount())}
P = load_keys()

# ---------- layout ----------
TABS = ["SWING", "SETUP"]
BG_ITEMS = {t: [] for t in TABS}
PLACED = {t: [] for t in TABS}
DEFS, IMAGES = {}, {}
def img(name, im): IMAGES[name] = im; return name
def defn(key, value): DEFS.setdefault(key, value); return key
def place(tab, name, dkey, param, x, y, w, h, kind, extra=None, touch=True):
    PLACED[tab].append(dict(name=name, dkey=dkey, param=param, x=x, y=y, w=w, h=h, kind=kind, extra=extra, touch=touch))

CTRL = lambda: [action("Mouse Down", "Q-Link"), action("Double Click", "Show Overlay", "knob overlay"), action("Enter Pressed", "Show Overlay", "knob overlay")]
def drag_knobs(w, h, orient="Vertical"):
    """An invisible drag area made the way the MPC accepts it: a grid of square knob pieces (<= 84 px, square filmstrip
    frames, each fully inside the control), all bound to the same parameter."""
    sq = int(min(84, h, w))
    nx, ny = max(1, w // sq), max(1, h // sq)
    x0, y0 = (w - nx * sq) // 2, (h - ny * sq) // 2
    strip = img(f"sb_drag{sq}.png", Image.new("RGBA", (sq, sq * FRAMES), (0, 0, 0, 0)))
    return [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": strip, "numFrames": NUMFRAMES, "invert": False,
                 "dragOrientation": orient, "handleName": "Data"}, bounds((x0 + i * sq, y0 + j * sq, sq, sq)))
            for j in range(ny) for i in range(nx)]
def d_box(w, h, fs=17):
    return defn(f"sbBox{w}x{h}_{fs}", definition(CTRL(), drag_knobs(w, h) + [label("Value", fs, LCD_COL, (0, 0, w, h), case="Upper Case"), focus((0, 0, w, h))]))
def d_text(w, h, fs, col=LCD_COL):
    return defn(f"sbText{w}x{h}_{fs}", definition([], [label("Value", fs, col, (0, 0, w, h))], ignore=True))

def section(tab, x0, x1, y, title): BG_ITEMS[tab].append(("section", x0, x1, y, title))
def box(tab, name, key, x, y, w=186, h=44, caption=None, fs=17):
    place(tab, name, d_box(w, h, fs), P[key], x, y, w, h, "box", fs)
    BG_ITEMS[tab].append(("lcd", x, y, w, h, caption))
def text(tab, name, key, x, y, w, h, fs=15):
    place(tab, name, d_text(w, h, fs), P[key], x, y, w, h, "text", fs, touch=False)
def keycap(tab, name, key, x, y, cap, big=False):
    place(tab, name, "sbBigKey" if big else "sbKey", P[key], x, y, BIG_W if big else KEY_W, KEY_H, "bigkey" if big else "key")
    BG_ITEMS[tab].append(("cap", x + (BIG_W if big else KEY_W) / 2, y + KEY_H + 10, cap))
def ruler(tab, x, y):
    place(tab, "Groove", "sbRuler", P["swing"], x, y, RP * RN, RP, "ruler", touch=False)
    BG_ITEMS[tab].append(("lcd", x, y, RP * RN, RP, "Groove  (two pairs of Grid steps)"))
def status(tab, x, y, w, h, fs=18):
    BG_ITEMS[tab].append(("lcd", x, y, w, h, None))
    text(tab, "Status", "info", x + 6, y + 4, w - 12, h - 8, fs)

# ---------- shared component definitions ----------
img("sb_key_on.png", key_image(True)); img("sb_key_off.png", key_image(False))
img("sb_bigkey_on.png", key_image(True, BIG_W)); img("sb_bigkey_off.png", key_image(False, BIG_W))
def keydef(name, on, off, w):
    defn(name, definition([action("Mouse Down", "Q-Link"), action("Enter Pressed", "Toggle Switch")], [
        focus((0, 0, w, KEY_H)),
        comp("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": 1,
             "numButtonsInGroup": 1, "handleName": "Data", "gestureBehaviour": "Instant"}, bounds((0, 0, w, KEY_H)))]))
keydef("sbKey", "sb_key_on.png", "sb_key_off.png", KEY_W)
keydef("sbBigKey", "sb_bigkey_on.png", "sb_bigkey_off.png", BIG_W)
for k, st in enumerate(ruler_strips()): img(f"sb_ruler{k}.png", st)
defn("sbRuler", definition([], [comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": f"sb_ruler{k}.png", "numFrames": NUMFRAMES,
     "invert": False, "dragOrientation": "Horizontal", "handleName": "Data"}, bounds((k * RP, 0, RP, RP))) for k in range(RN)], ignore=True))

# ================================================================= SWING page
T = "SWING"
box(T, "Swing", "swing", 40, 92, w=420, h=168, caption="SWING  (drag, or turn Q-Link 1)", fs=110)
ruler(T, 520, 92)
box(T, "Grid", "grid", 520, 216, w=150, h=44, caption="Grid")
box(T, "Sync", "sync", 690, 216, w=166, h=44, caption="Sync")
keycap(T, "Sync Tap", "tap", 1110, 90, "SYNC")
keycap(T, "Bypass", "bypass", 1190, 90, "BYPASS")
box(T, "Tempo", "bpm", 1060, 216, w=196, h=44, caption="Tempo (Host = MPC)")
section(T, 40, 1256, 300, "Live A/B  (switch while it plays)")
for i, (k, cap) in enumerate((("kstraight", "STRAIGHT"), ("k60", "MPC60"), ("k2000", "MPC2000"), ("k3000", "MPC3000"), ("k4000", "MPC4000"), ("klinn", "LINNDRUM"))):
    keycap(T, cap, k, 40 + i * 124, 340, cap, big=True)
box(T, "Grid Offset", "offset", 800, 362, w=200, h=44, caption="Grid Offset")
box(T, "Gap Fill", "gap", 1040, 362, w=216, h=44, caption="Gap Fill")
status(T, 40, 486, 1216, 64)

# ================================================================= SETUP page
T = "SETUP"
section(T, 40, 620, 52, "The seams")
box(T, "Gap Fill", "gap", 40, 122, caption="Gap Fill")
box(T, "Seam", "xfade", 250, 122, caption="Seam (crossfade)")
section(T, 660, 1256, 52, "The grid")
box(T, "Grid", "grid", 660, 122, w=150, caption="Grid")
box(T, "Grid Offset", "offset", 830, 122, w=190, caption="Grid Offset")
box(T, "Model", "model", 1040, 122, w=216, caption="Model")
section(T, 40, 1256, 200, "Sync")
box(T, "Sync", "sync", 40, 270, caption="Sync")
box(T, "Tempo", "bpm", 250, 270, caption="Tempo (Host = MPC)")
keycap(T, "Sync Tap", "tap", 470, 244, "SYNC")
keycap(T, "Bypass", "bypass", 560, 244, "BYPASS")
BG_ITEMS[T].append(("legend", 660, 236, [
    "Host: locks to the MPC sequencer (press PLAY).",
    "Free: no MPC beat? Tap SYNC, then the next hit = the 1.",
    "Gap Fill: Repeat = the end of the first step again;",
    "Silence = cleaner hits on drums. Seam: 1-3 ms.",
    "Grid: 1/4 to 1/128. Fine grids: use MPC4000 (960 PPQN).",
    "LinnDrum: the dial snaps to 50/54/58/62/66/71 %.",
    "Grid Offset: nudge if the swing feels early or late."]))
section(T, 40, 1256, 420, "Status")
status(T, 40, 466, 1216, 64)

QL = {
    "SWING": ["swing", "model", "grid", "offset", "sync", "bpm", "gap", "xfade", "tap", "bypass", "kstraight", "k60"],
    "SETUP": ["swing", "model", "grid", "offset", "sync", "bpm", "gap", "xfade", "tap", "bypass", "k4000", "klinn"],
}

# ---------- backgrounds ----------
def panel_bg(title_right):
    random.seed(9)
    im = Image.new("RGB", (W, H), BODY); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-2, 2); px[x, y] = (BODY[0] + n, BODY[1] + n, BODY[2] + n)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, 40], fill=(58, 58, 60)); d.rectangle([0, H - 26, W, H], fill=(58, 58, 60))
    d.line([0, 40, W, 40], fill=(30, 30, 32), width=2)
    d.text((24, 6), "SWING BOX", font=font(24), fill=(236, 232, 222))
    d.text((190, 15), spaced("SCRATCHLAB  GROOVE  TIMING  PROCESSOR", 2), font=font(9), fill=(190, 186, 176))
    tw = d.textlength(spaced(title_right), font=font(13)); d.text((W - 24 - tw, 13), spaced(title_right), font=font(13), fill=(236, 232, 222))
    d.text((24, H - 20), "ScratchLab", font=font(12, "DejaVuSans.ttf"), fill=(190, 186, 176))
    d.rectangle([W - 120, H - 20, W - 24, H - 8], fill=LED)
    return im, d

def background(tab):
    im, d = panel_bg(tab)
    for item in BG_ITEMS[tab]:
        k = item[0]
        if k == "section":
            _, x0, x1, y, title = item
            d.text((x0, y), title, font=font(17), fill=INK)
            d.line([x0, y + 26, x1, y + 26], fill=RULE, width=2)
        elif k == "lcd":
            _, x, y, w, hh, cap = item
            d.rounded_rectangle([x - 6, y - 6, x + w + 6, y + hh + 6], radius=6, fill=(70, 68, 64))
            d.rounded_rectangle([x - 3, y - 3, x + w + 3, y + hh + 3], radius=4, fill=(8, 10, 8))
            d.rectangle([x, y, x + w, y + hh], fill=LCD_BG)
            if cap: d.text((x, y - 26), cap, font=font(13), fill=INK_DIM)
        elif k == "legend":
            _, x, y, lines = item
            for j, ln in enumerate(lines): d.text((x, y + j * 28), ln, font=font(15, "DejaVuSans.ttf"), fill=INK)
        elif k == "cap":
            _, cx, cy, cap = item
            text_c(d, cx, cy, cap, font(11), INK)
    return im

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    defs = []
    for tab in TABS:
        bgname = f"sb_bg_{tab.lower()}.png"
        IMAGES[bgname] = background(tab)
        comps = [comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": bgname}, bounds((0, 0, W, H)))]
        for pl in sorted(PLACED[tab], key=lambda q: 1 if q["touch"] else 0):     # read-outs under, touch controls on top
            comps.append(comp(pl["name"], pl["dkey"], {"version": 1, "handleName": "Data"},
                              bounds((pl["x"], pl["y"], pl["w"], pl["h"]), focus="Yes" if pl["touch"] else "No", show="Hide" if pl["touch"] else "Show"),
                              {"version": 1, "map": [{"key": "Data", "value": f"Parameter {pl['param']}"}]}))
        DEFS[f"SB|{tab}"] = definition([], comps, "ffbebab0")
    for k, v in DEFS.items(): defs.append({"key": k, "value": v})
    tabs = [{"version": 3, "tabName": t, "fnKeyIndex": i, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": f"SB|{t}", "initialSize": f"0 0 {W} {H}", "scale": 1.0} for i, t in enumerate(TABS)]
    tui = {"pageData": {"version": 1,
        "componentDefinitions": {"version": 2, "importFiles": ["/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json",
                                                                "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
                                 "localComponentDefinitions": defs},
        "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=2)
    qmap = lambda keys: {f"Q-Link {i + 1}": P[k] for i, k in enumerate(keys)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": i + 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap(QL[t])} for i, t in enumerate(TABS)]},
         "Program Mode Q-Links": qmap(QL["SWING"])}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=2)
    total = 0
    for name, im in IMAGES.items():
        im.save(os.path.join(OUT, name), optimize=True); total += im.size[0] * im.size[1] * 4
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>scratchlab.vst.swingbox</identifier>\n"
        "\t<version>1.0.0.0</version>\n</plugincontent>\n")
    print(f"skin written to {SKIN_DIR}: {len(IMAGES)} images + TUI.json + Q-Links, {total / 1e6:.1f} MB decoded")

# ---------- preview (what the screen should look like, drawn from the same layout) ----------
def preview(outdir):
    os.makedirs(outdir, exist_ok=True)
    vals = {"k60": 1, "tap": 0, "bypass": 0, "kstraight": 0, "k2000": 0, "k3000": 0, "k4000": 0, "klinn": 0}
    swing = 57
    txt = {"swing": f"{swing}%", "grid": "1/16", "sync": "Host", "bpm": "Host", "offset": "+0.0 ms", "gap": "Repeat", "xfade": "2.0 ms",
           "model": "MPC60", "info": "LOCKED 92 BPM MPC | MPC60 1/16 57% +20.4 ms"}
    inv = {v: k for k, v in P.items()}
    cache = {}
    def im_(n):
        if n not in cache: cache[n] = Image.open(os.path.join(OUT, n)).convert("RGBA")
        return cache[n]
    sheets = []
    for tab in TABS:
        im = im_(f"sb_bg_{tab.lower()}.png").copy(); d = ImageDraw.Draw(im)
        for pl in PLACED[tab]:
            x, y, w, h = int(pl["x"]), int(pl["y"]), int(pl["w"]), int(pl["h"]); key = inv[pl["param"]]; k = pl["kind"]
            if k == "ruler":
                fr = round((swing - 50) / 25 * NUMFRAMES)
                for k2 in range(RN): im.alpha_composite(im_(f"sb_ruler{k2}.png").crop((0, fr * RP, RP, fr * RP + RP)), (x + k2 * RP, y))
            elif k in ("key", "bigkey"):
                pre = "sb_bigkey" if k == "bigkey" else "sb_key"
                im.alpha_composite(im_(f"{pre}_{'on' if vals.get(key, 0) >= 0.5 else 'off'}.png"), (x, y))
            elif k in ("box", "text"):
                s = txt[key].upper() if k == "box" else txt[key]
                size = int(pl["extra"] * 0.8); f = font(size)
                while d.textlength(s, font=f) > w - 8 and size > 7: size -= 1; f = font(size)
                text_c(d, x + w / 2, y + h / 2, s, f, LCD_TXT)
        path = os.path.join(outdir, f"skin-preview-{tab.lower()}.png")
        im.convert("RGB").save(path); sheets.append(im.convert("RGB")); print("preview:", path)

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
